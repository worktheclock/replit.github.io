#!/bin/bash

if ! javac Example.java
then
    printf "\n\n--------------------\nYou code doesn't compile! Please run it in test mode first by using `ReadyForSubmission=NO` in Example.java\n--------------------\n"
    exit 1
fi

if cat Example.java | grep -q "ReadyForSubmission=YES"; then
  curl -X POST \
       -H "Content-Type: multipart/form-data" \
       -F "codefile=@Example.java" \
       https://test-java-server.ritza.repl.co
else
  javac Example.java
  java Example
fi
